package com.SprongBootProject.CREDOperation;

public class Employee {
	private int eid;
	private String name;
	private double salary;
	private String profile;

	// Default
	// para
	// getter and setter
	// toString

	public Employee(int eid, String name, double salary, String profile) {
		super();
		this.eid = eid;
		this.name = name;
		this.salary = salary;
		this.profile = profile;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", name=" + name + ", salary=" + salary + ", profile=" + profile + "]";
	}

}
