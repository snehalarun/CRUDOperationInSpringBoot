package com.SprongBootProject.CREDOperation;

public class ACHolder {
	private int acnumber;
	private String name;
	private double balance;

	public ACHolder(int acnumber, String name, double balance) {
		super();
		this.acnumber = acnumber;
		this.name = name;
		this.balance = balance;
	}

	public int getAcnumber() {
		return acnumber;
	}

	public String getName() {
		return name;
	}

	public double getBalance() {
		return balance;
	}

	@Override
	public String toString() {
		return "ACHolder [acnumber=" + acnumber + ", name=" + name + ", balance=" + balance + "]";
	}

}
