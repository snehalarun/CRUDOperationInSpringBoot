package com.SprongBootProject.CREDOperation;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Connection;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

	ArrayList<Employee> dm = new ArrayList<>();

	@GetMapping("/studentData")
	ArrayList<Student> getData() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "root");
		Statement stm = con.createStatement();
		ResultSet rs = stm.executeQuery("Select * from student");
		ArrayList<Student> st1 = new ArrayList<>();
		while (rs.next()) {
			int id = rs.getInt(1);
			String name = rs.getString("name");
			double marks = rs.getDouble("marks");
			int rollnumber = rs.getInt("rollnumber");
			Student st = new Student(id, name, marks, rollnumber);
			st1.add(st);

		}
		return st1;
	}

	@GetMapping("/bankData")
	public ArrayList<ACHolder> getDataOfHolder() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bankofindia", "root", "root");
		Statement stm = con.createStatement();
		ResultSet res = stm.executeQuery("Select * from bank");
		ArrayList<ACHolder> ac = new ArrayList<>();
		while (res.next()) {
			int acnum = res.getInt(1);
			String name = res.getString(2);
			double balance = res.getDouble(3);
			ACHolder ac1 = new ACHolder(acnum, name, balance);
			ac.add(ac1);
		}
		return ac;
	}

	@GetMapping("/dmartData")
	ArrayList<Dmart> dmartData() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dmart", "root", "root");
		Statement stm = con.createStatement();
		ResultSet res = stm.executeQuery("Select * from customer");
		ArrayList<Dmart> dm = new ArrayList<>();
		while (res.next()) {
			int id = res.getInt(1);
			String name = res.getString(2);
			String product = res.getString(3);
			int price = res.getInt(4);
			int numberOfproduct = res.getInt(5);
			double total = res.getDouble(6);
			Dmart dmm = new Dmart(id, name, product, price, numberOfproduct, total);
			dm.add(dmm);

		}
		return dm;
	}

	@PostMapping("/data/{name}")
	String data(@PathVariable String name) {
		System.out.println(name);
		return "done";
	}

	@PostMapping("/javaby/{name}")
	String name(@PathVariable String name) {
		System.out.println("Java By " + name);
		return "done";
	}

	@PostMapping("/country/{country}")
	String country(@PathVariable String country) {
		System.out.println(" I love my " + country);
		return country;
	}

	@PostMapping("/courseName")
	String course(@RequestBody String course) {
		System.out.println("My course is " + course);
		return course;
	}

	@PostMapping("/xyz")
	String xyz(@RequestBody String data) {
		System.out.println(data);
		return data;
	}

	@PostMapping("/friendName")
	String frdName(@RequestBody String name) {
		return "My Best friend Name is " + name;
	}

	@PutMapping("/welcome/{x}")
	String val(@PathVariable String x) {
		String p = "JavaByKiran";
		System.out.println("Old Value : " + p);
		p = x;
		System.out.println("New Value : " + p);
		return "Value Updated";
	}

	@PutMapping("name/{name}")
	String name1(@PathVariable String name) {
		String x = "Vipul";
		System.out.println(x);
		x = name;
		System.out.println(x);
		return "Update Successfully";
	}

	@PutMapping("/hobbies")
	String hobby(@RequestBody String hobbies) {
		String hb = "Singing";
		System.out.println(hb);
		hb = hobbies;
		System.out.println(hb);
		return "Update Successfully";
	}

	// @PostMapping("/employee")
	// String empdata(@RequestBody Employee e) {
	//
	// dm.add(e);
	//
	// System.out.println("Employee Id : " + e.getEid());
	// System.out.println("Employee Name : " + e.getName());
	// System.out.println("Empoyee Salary : " + e.getSalary());
	// System.out.println("Employee Profile : " + e.getProfile());
	// return "Data Inserted";
	// }
	
	
	
	


	
}
