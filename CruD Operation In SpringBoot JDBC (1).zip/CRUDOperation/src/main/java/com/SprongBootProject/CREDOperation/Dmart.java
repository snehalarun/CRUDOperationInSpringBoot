package com.SprongBootProject.CREDOperation;

public class Dmart {
	private int id;
	private String name;
	private String product;
	private int price;
	private int numberOfProduct;
	private double bill;

	public Dmart(int id, String name, String product, int price, int numberOfProduct, double bill) {
		super();
		this.id = id;
		this.name = name;
		this.product = product;
		this.price = price;
		this.numberOfProduct = numberOfProduct;
		this.bill = bill;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getNumberOfProduct() {
		return numberOfProduct;
	}

	public void setNumberOfProduct(int numberOfProduct) {
		this.numberOfProduct = numberOfProduct;
	}

	public double getBill() {
		return bill;
	}

	public void setBill(double bill) {
		this.bill = bill;
	}

	@Override
	public String toString() {
		return "Dmart [id=" + id + ", name=" + name + ", product=" + product + ", price=" + price + ", numberOfProduct="
				+ numberOfProduct + ", bill=" + bill + "]";
	}

}
