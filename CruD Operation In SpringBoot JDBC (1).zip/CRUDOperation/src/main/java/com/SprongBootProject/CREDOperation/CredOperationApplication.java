package com.SprongBootProject.CREDOperation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CredOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CredOperationApplication.class, args);
	}

}
